import type { Product } from './ProductList.data';
export default function ProductList({ mfData }: {
    mfData?: Product[];
}): import("react/jsx-runtime").JSX.Element;
